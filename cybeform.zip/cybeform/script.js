document.getElementById('cadastroForm').addEventListener('submit', function (e) {
  e.preventDefault();
  document.getElementById('msg').innerText = "✅ Cadastro realizado com sucesso!";
});
